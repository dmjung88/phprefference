<?php

	define (DB_USER, "root");

	define (DB_PASSWORD, "");

	define (DB_DATABASE, "data");

	define (DB_HOST, "localhost");

	$mysqli = new mysqli(localhost, root, , data);

?>