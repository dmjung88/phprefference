# A simple CRUD Application complete build with ajax.
 This is a single page full CRUD application (as for as the front page is concern) with ajax 
 no page referesh no redirection everything is realtime.

# How to run this application
Paste the `PHP Ajax` folder in htdocs
make a database named `ajax` and import the `cars.sql` file for the data base 

Go to http://localhost/PHP%20Ajax/

# NOTE :


I have not Followed the Object Oriented approach or good practices in this application
For example I have made connection on every `PHP` file instead of making it in seperate file
I have used same HTML `id` for multiple elements. I haven't made function for displaying the data realtime
instead I am coping and pasting code each time where I need to render the data from `data Base`


The purpose of this application was just to show you the power of ajax although you can impliment this application in much better way but the basic `ajax` concept is the same 
