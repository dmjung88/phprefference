print ("Nothing")
