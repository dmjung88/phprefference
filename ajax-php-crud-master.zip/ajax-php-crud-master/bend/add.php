<?php
require_once('functions/func.php');
add_data($_POST);
?>
