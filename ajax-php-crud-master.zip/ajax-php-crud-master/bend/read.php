<?php
require_once('functions/func.php');

view_data();

?>