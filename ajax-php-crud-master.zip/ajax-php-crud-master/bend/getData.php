<?php
require_once('functions/func.php');
getData($_POST);
?>