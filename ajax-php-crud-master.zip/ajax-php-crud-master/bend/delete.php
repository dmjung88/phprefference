<?php
require_once('functions/func.php');

deleteData($_POST);
?>