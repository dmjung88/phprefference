<?php
require_once('functions/func.php');

editData($_POST);

?>