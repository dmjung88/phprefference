# Simple CRUD Systems with PHP + OOP and JQUERY AJAX

Created with PHP + OOP Concept. Also, CRUD process are handled with ajax based on jquery library. 

The systems are including these features :
- View Data
- Insert Data
- Update Data
- Delete Data
- Upload Image
